# Face-Recognition-Attendance-System
Face Recognition Attendance System with Python 3.6 and OpenCV 3.4
### Steps to follow: 
- Start this project from firstpage.py
- Create dataset by clicking create dataset button.
- Train this by clicking dataset button
- click on recognize + attendance button to start recognizing and marking attendance.
- Click on Attendance Sheet to view current date attendance sheet.

 ### Note : 
 - Please download libraries accordingly by opening python file : tkinter,firebase,numpy,pillow,xlwrite,opencv3.4
 - Run it using python 3.6
