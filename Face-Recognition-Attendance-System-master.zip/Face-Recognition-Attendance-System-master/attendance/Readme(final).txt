1.Start this project from firstpage.py
2.Create dataset by clicking create dataset button.
3.Train this by clicking dataset button
4.click on recognize + attendance button to start recognizing and marking attendance.
5.Click on Attendance Sheet to view current date attendance sheet.


Note:1. Please download libraries accordingly by opening python file : tkinter,firebase,numpy,pillow,xlwrite,opencv3.4

     2. Run it using python 3.6